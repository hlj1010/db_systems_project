d.db d2.db d3.db:
     3 version of the database

Final_Report.pdf:
	Final Report - All sections mention and explain the corresponding filenames

java_src/:
	All the java code used for project

copy_queries/:
	DDL files to create the 3 versions of the database

select_queries/:
	All query implementation from step 8

NOTE: all sql code is avaliable as snippets in the report

result.csv:
	datapoints from step 9. each row is time in ns for the query represented by the column header.

NOTE: the database and query numbering is consistent throughout all documentation and code.
